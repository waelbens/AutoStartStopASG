import boto3

client = boto3.client('autoscaling')
describe = client.describe_auto_scaling_groups()

def handler(event, context):

    asgs = []
    
    all_asgs = describe['AutoScalingGroups']
    for asg in range(len(all_asgs)):
        all_tags = all_asgs[asg]['Tags']
        for tag in range(len(all_tags)):
            if 'site' in all_tags[tag]['Key'] and event['site'] in all_tags[tag]['Value']:
                asgs.append(all_tags[tag]['ResourceId'])

    for asg in asgs:   
        if event['action'] == "start":           
            action = "Starting"
            min_size = 1
            max_size = 1
            desired_capacity = 1
        if event['action'] == "stop":  
            action = "Stopping"
            min_size = 0
            max_size = 1
            desired_capacity = 0
    
        print action + ": " + asg
        response = client.update_auto_scaling_group(
            AutoScalingGroupName=asg,
            MinSize=min_size,
            MaxSize=max_size,
            DesiredCapacity=desired_capacity,
        )

        print response
    return asgs
